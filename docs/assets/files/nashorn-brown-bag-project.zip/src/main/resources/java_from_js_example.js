// use Java.type to make classes available in JS
var File = Java.type("java.io.File");

// java is a special Nashorn object that gives access to the Java system packages
var f = new File(java.util.UUID.randomUUID().toString()+".txt");
f.createNewFile();