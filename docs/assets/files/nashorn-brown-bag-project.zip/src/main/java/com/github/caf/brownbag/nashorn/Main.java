package com.github.caf.brownbag.nashorn;

import java.io.File;
import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

/**
 * Entrypoint for Nashorn brown bag demo.
 */
public class Main {

    public static void main(String args[])
            throws URISyntaxException, IOException, ScriptException, NoSuchMethodException, InterruptedException {
        //invokeFunctionExample();
        //invokeMethodExample();
        //implementInterfaceExample();
        useJavaClassInJsExample();
    }
    
    private static void invokeFunctionExample() throws IOException, ScriptException, NoSuchMethodException, URISyntaxException{
        // define the values to pass to the script
        List<Integer> arguments = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8);

        URL testJsUrl = Main.class.getResource("/from_java_example.js");
        Path testJsPath = Paths.get(testJsUrl.toURI());
        String testJs = new String(
                Files.readAllBytes(testJsPath), StandardCharsets.UTF_8);

        // Create a ScriptEngineManager object to allow us to retrieve the Nashorn script engine
        final ScriptEngineManager engineManager = new ScriptEngineManager();
        // Retrieve the Nashorn script engine, note that Java supports other script engines. Nashorn is included by default
        final ScriptEngine engine = engineManager.getEngineByName("nashorn");
        // Evaluate the script so we can call functions in the script
        engine.eval(testJs);
        Invocable invoker = (Invocable) engine;
        // Call the 'run' function in our script, passing the List of Integers defined earlier.
        invoker.invokeFunction("run", arguments);
    }
    
    private static void invokeMethodExample() throws ScriptException, NoSuchMethodException {
        ScriptEngineManager manager = new ScriptEngineManager();
        ScriptEngine engine = manager.getEngineByName("nashorn");

        // evaluate JavaScript code that defines an object with one method
        engine.eval("var obj = new Object()");
        engine.eval("obj.hello = function(name) { print('Hello ' + name) }");

        // expose object defined in the script to the Java application
        Object obj = engine.get("obj");

        // create an Invocable object by casting the script engine object
        Invocable inv = (Invocable) engine;

        // invoke the method named "hello" on the object defined in the script
        // with "Script Method!" as the argument
        inv.invokeMethod(obj, "hello", "Belfast");
    }
    
    private static void implementInterfaceExample() throws ScriptException, InterruptedException{
        ScriptEngineManager manager = new ScriptEngineManager();
        ScriptEngine engine = manager.getEngineByName("nashorn");

        // evaluate JavaScript code that defines a function with one parameter
        engine.eval("function run() { print('The run() function was called.') }");

        // create an Invocable object by casting the script engine object
        Invocable inv = (Invocable) engine;

        // Returns an implementation of an interface using functions compiled in the interpreter
        Runnable r = inv.getInterface(Runnable.class);

        // start a new thread that runs the script
        Thread th = new Thread(r);
        th.start();
        th.join();
    }
    
    private static void useJavaClassInJsExample() throws URISyntaxException, IOException, ScriptException{
        ScriptEngineManager manager = new ScriptEngineManager();
        ScriptEngine engine = manager.getEngineByName("nashorn");
        
        URL testJsUrl = Main.class.getResource("/java_from_js_example.js");
        Path testJsPath = Paths.get(testJsUrl.toURI());
        String testJs = new String(
                Files.readAllBytes(testJsPath), StandardCharsets.UTF_8);
        engine.eval(testJs);
    }
}
