function run(arguments){
  var result = 0;

  for each(var argument in arguments){
    if(isNaN(argument)===false){
      result += Number(argument);
    }
  }

  print(result);
}
